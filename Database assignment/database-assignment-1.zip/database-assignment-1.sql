-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 25, 2020 at 12:15 AM
-- Server version: 10.1.40-MariaDB
-- PHP Version: 7.3.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `database-assignment-1`
--

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

CREATE TABLE `company` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `company`
--

INSERT INTO `company` (`id`, `name`) VALUES
(1, 'facebook'),
(2, 'amazon'),
(3, 'google'),
(4, 'youtube'),
(5, 'microsoft');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `section` enum('computer','communication','control') DEFAULT 'computer'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`id`, `name`, `section`) VALUES
(1, 'entesar', 'computer'),
(2, 'esra', 'computer'),
(3, 'ayman', 'communication'),
(4, 'alaref', 'control'),
(5, 'ayoup', 'computer'),
(6, 'anas', 'control'),
(7, 'mohammed', 'computer'),
(8, 'ali', 'communication'),
(9, 'absy', 'communication'),
(10, 'ahmed', 'communication'),
(11, 'abdalaleam', 'control'),
(12, 'alaa', 'computer'),
(13, 'razan', 'control'),
(14, 'aya', 'communication'),
(15, 'ekhlass', 'computer'),
(16, 'areej', 'communication'),
(17, 'abdulrauf', 'control');

-- --------------------------------------------------------

--
-- Table structure for table `employee_company`
--

CREATE TABLE `employee_company` (
  `employee_id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `start_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `employee_company`
--

INSERT INTO `employee_company` (`employee_id`, `company_id`, `start_date`) VALUES
(11, 4, '2010-10-10'),
(17, 3, '2010-10-10'),
(9, 2, '2010-10-10'),
(10, 1, '2010-10-10'),
(12, 5, '2010-10-10'),
(4, 2, '2010-10-10'),
(8, 3, '2010-10-10'),
(6, 1, '2010-10-10'),
(16, 4, '2010-10-10'),
(14, 3, '2010-10-10'),
(3, 2, '2010-10-10'),
(5, 5, '2010-10-10'),
(15, 1, '2010-10-10'),
(1, 2, '2010-10-10'),
(2, 3, '2010-10-10'),
(7, 2, '2010-10-10'),
(13, 5, '2010-10-10'),
(10, 5, '2011-11-11'),
(11, 3, '2011-11-11'),
(12, 1, '2011-11-11'),
(13, 2, '2011-11-11'),
(14, 4, '2011-11-11'),
(15, 5, '2011-11-11'),
(16, 4, '2011-11-11'),
(17, 5, '2011-11-11'),
(15, 3, '2012-12-12'),
(16, 2, '2012-12-12'),
(17, 4, '2012-12-12');

-- --------------------------------------------------------

--
-- Stand-in structure for view `full_view`
-- (See below for the actual view)
--
CREATE TABLE `full_view` (
`employee_name` text
,`company_name` text
,`start_date` date
);

-- --------------------------------------------------------

--
-- Structure for view `full_view`
--
DROP TABLE IF EXISTS `full_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `full_view`  AS  select `employee`.`name` AS `employee_name`,`company`.`name` AS `company_name`,`employee_company`.`start_date` AS `start_date` from ((`employee` join `company`) join `employee_company`) where ((`employee_company`.`company_id` = `company`.`id`) and (`employee_company`.`employee_id` = `employee`.`id`)) order by `employee`.`id` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `company`
--
ALTER TABLE `company`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employee_company`
--
ALTER TABLE `employee_company`
  ADD KEY `employee_id` (`employee_id`),
  ADD KEY `company_id` (`company_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `company`
--
ALTER TABLE `company`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `employee_company`
--
ALTER TABLE `employee_company`
  ADD CONSTRAINT `employee_company_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`id`),
  ADD CONSTRAINT `employee_company_ibfk_2` FOREIGN KEY (`company_id`) REFERENCES `company` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
