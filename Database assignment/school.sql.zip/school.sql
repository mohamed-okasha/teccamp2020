-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3308
-- Generation Time: 18 أبريل 2020 الساعة 11:49
-- إصدار الخادم: 8.0.18
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `school`
--

-- --------------------------------------------------------

--
-- بنية الجدول `enrollment`
--

DROP TABLE IF EXISTS `enrollment`;
CREATE TABLE IF NOT EXISTS `enrollment` (
  `enrollment_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  PRIMARY KEY (`enrollment_id`),
  KEY `student_id` (`student_id`),
  KEY `subject_id` (`subject_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- إرجاع أو استيراد بيانات الجدول `enrollment`
--

INSERT INTO `enrollment` (`enrollment_id`, `student_id`, `subject_id`) VALUES
(215, 10, 1),
(216, 20, 2),
(217, 30, 3);

-- --------------------------------------------------------

--
-- بنية الجدول `student`
--

DROP TABLE IF EXISTS `student`;
CREATE TABLE IF NOT EXISTS `student` (
  `student_name` text,
  `id` int(11) DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL,
  `subject_name` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- إرجاع أو استيراد بيانات الجدول `student`
--

INSERT INTO `student` (`student_name`, `id`, `address`, `subject_name`) VALUES
('mohamed', 10, 'benghazi', 'math'),
('mohamed', 10, 'benghazi', 'english language'),
('mohamed', 10, 'benghazi', 'chemistry'),
('ali', 20, 'tripoli', 'arabic'),
('ali', 20, 'tripoli', 'phisics'),
('ahmed', 30, 'tripoli', 'programming'),
('ahmed', 30, 'tripoli', 'history');

-- --------------------------------------------------------

--
-- بنية الجدول `subject`
--

DROP TABLE IF EXISTS `subject`;
CREATE TABLE IF NOT EXISTS `subject` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `subject_name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `student_id` (`student_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- إرجاع أو استيراد بيانات الجدول `subject`
--

INSERT INTO `subject` (`id`, `student_id`, `subject_name`) VALUES
(1, 10, 'math'),
(2, 10, 'english language'),
(3, 10, 'chimestry'),
(4, 10, 'arabic'),
(5, 20, 'phisics'),
(6, 30, 'programming'),
(7, 30, 'history');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
