class Student():

    def __init__(self, name, grade):
        self.name = name
        self.grade = grade

    def print_info(self, name, grade, grading):
        print("Name : {}  | Grade : {}  | Grading : {}".format(
            self.name, self.grade, grading))

# /////////////////////////////////////User input/////////////////////////////////////////////////


def user_input():
    s = []
    length = int(input("please enter the students number : "))
    for i in range(length):
        name = input("please enter the name of  student : ")
        grade = input("please enter the student grade : ")
        s.append(Student(name, grade))
    return s

# ///////////////////////////////////////Grading function////////////////////////////////////////////////


def grading(grade):
    if grade >= 85:
        return "exelent"
    elif grade > 70:
        return "very good"
    elif grade > 50 or grade == 70:
        return "good"
    else:
        return "poor"

# ////////////////////////////////////Print student info///////////////////////////////////////////////////


def print_students(students):
    for s in students:
        gpa = grading(int(s.grade))
        s.print_info(s.name, s.grade, gpa)

# /////////////////////////////////////Print students info in a text file//////////////////////////////////////////////////


def print_file(students):
    with open('stdInfo.txt', 'w') as f:
        for student in students:
            f.write("Name : {}  | Grade : {}  | Grading : {} \n".format(
                student.name, student.grade, grading(int(student.grade))))
        f.close()

# /////////////////////////////////////Function calls//////////////////////////////////////////////////


students = user_input()
print_students(students)
print_file(students)
