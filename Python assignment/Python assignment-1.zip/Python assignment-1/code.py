import re

number = input("Enter students number:\n")
n = int(number)

ST = []

for x in range(0, n):
    ST.append([str(input("\nEnter the student name:\n")), int(input("Enter the student grade:\n"))])
    s = ST[x]
    sn = s[0]
    sna = str(sn)
    snam = re.findall("[+.|()#$%^@ &*!-/\`>}<;:,'{]", sna)
    sname = re.findall("^\d", sna)
    if snam or sname:
      if snam:
        print(snam)
        print("the name can't have this character\s :)")
      elif sname:
        print(sname)
        print("Don't start with number\s!")
      while (True):
        sn = (str(input("plz Try alternative name:\n")))
        na = sn
        name = re.findall("[+.|()#$%^@ &*!-/\`>}<;:,'{]", na)
        nam = re.findall("^\d", na)
        print("\n")
        if name:
          print(name)
          print("the name can't have this character\s :)")
        elif nam:
          print(nam)
          print("Don't start with number\s!")
        if not (name) and not (nam):
          break
    else:
        pass
    s[0] = sn
    com = ST[x]
    co = com[1]
    if co < 0 or co > 100:
        while (True):
            print("\ninvalid Grade, must be between 0 and 100 :)")
            co = (int(input("plz Try Again:\n")))
            nums = co
            if nums >= 0 and nums <= 100:
                break
    com[1] = co

for y in ST:
    num = y[1]
    if num >= 85 and num <= 100:
        y.append(" Exellent")
    elif num > 70 and num < 85:
        y.append(" Very Good")
    elif num > 50 and num <= 70:
        y.append("Good")
    elif num == 50:
        y.append(" lucky, no instructions given :)")
    elif num < 50:
        y.append(" Poor")

for i in ST:
    print(i)

while(True):
    q = input("Do u wanna add'a' new students, or overwrite'r' the existing content?\nanswer('a' or 'r')\n")
    if q == "a":
        NandG = open("NandG.txt", "a")
        for k in ST:
            NandG = open("NandG.txt", "a")
            j = 0
            for j in range(3):
                if j == 0:
                    w = k[j]
                    wr = str(w)
                    NandG.write(wr + "\t")
                elif j == 1:
                    continue
                elif j == 2:
                    w = k[j]
                    wr = str(w)
                    NandG.write(wr + "\n")
        NandG.close()
        break

    elif q == "r":
        NandG = open("NandG.txt", "w")
        for k in ST:
            NandG = open("NandG.txt", "a")
            j = 0
            for j in range(3):
                if j == 0:
                    w = k[j]
                    wr = str(w)
                    NandG.write(wr + "\t")
                elif j == 1:
                    continue
                elif j == 2:
                    w = k[j]
                    wr = str(w)
                    NandG.write(wr + "\n")
        NandG.close()
        break

    else:
        print("can't take that as an answer, sorry :(\nTry again:")
        continue

NandG = open("NandG.txt", "r")

print(NandG.read())

print("\nthere are some conditions for the Student-Name in case u didn't notice.\nhave fun trying :)")